package com.example.voicecontrol

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout

/** Floating eyes drawn over every app (via the accessibility service) + a fake "screen off" sleep mode. */
class EyesOverlay(private val svc: AccessibilityService) {

    private val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private var small: EyesView? = null
    private var sleepRoot: FrameLayout? = null
    private var sleepEyes: EyesView? = null
    private var base = Mood.IDLE

    val sleeping: Boolean get() = sleepRoot != null

    private val revert = Runnable { small?.mood = base }
    private val peek = object : Runnable {
        override fun run() {
            val e = sleepEyes ?: return
            e.mood = Mood.CURIOUS
            handler.postDelayed({ sleepEyes?.mood = Mood.SLEEPY }, 2500L)
            handler.postDelayed(this, 12000L + (Math.random() * 10000).toLong())
        }
    }

    private fun main(block: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) block() else handler.post { block() }
    }

    fun show() = main {
        if (small != null || sleepRoot != null) return@main
        val d = svc.resources.displayMetrics.density
        val v = EyesView(svc)
        val lp = WindowManager.LayoutParams(
            (190 * d).toInt(), (64 * d).toInt(),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.y = (6 * d).toInt()
        try { wm.addView(v, lp); small = v; v.mood = base } catch (e: Exception) { }
    }

    fun hide() = main {
        small?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        small = null
    }

    fun setMood(m: Mood, ms: Long = 0) = main {
        handler.removeCallbacks(revert)
        if (ms <= 0L) base = m
        small?.mood = m
        if (ms > 0L) handler.postDelayed(revert, ms)
    }

    fun enterSleep() = main {
        if (sleepRoot != null) return@main
        hide()
        val d = svc.resources.displayMetrics.density
        val root = FrameLayout(svc)
        root.setBackgroundColor(Color.BLACK)
        val eyes = EyesView(svc)
        eyes.mood = Mood.SLEEPY
        root.addView(
            eyes,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (260 * d).toInt(), Gravity.CENTER)
        )
        root.setOnClickListener { exitSleep() }
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
            PixelFormat.TRANSLUCENT
        )
        lp.screenBrightness = 0.01f
        try {
            wm.addView(root, lp)
            sleepRoot = root
            sleepEyes = eyes
            handler.postDelayed(peek, 9000L)
        } catch (e: Exception) { if (Prefs.eyesOn(svc)) show() }
    }

    fun exitSleep() = main {
        handler.removeCallbacks(peek)
        sleepRoot?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        sleepRoot = null
        sleepEyes = null
        if (Prefs.eyesOn(svc)) show()
        setMood(Mood.HAPPY, 2500L)
    }

    fun release() = main {
        handler.removeCallbacksAndMessages(null)
        sleepRoot?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        small?.let { try { wm.removeView(it) } catch (e: Exception) { } }
        sleepRoot = null
        sleepEyes = null
        small = null
    }
}
