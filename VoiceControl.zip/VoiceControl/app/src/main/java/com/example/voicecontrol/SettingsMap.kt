package com.example.voicecontrol

import android.content.Context
import android.content.Intent
import android.provider.Settings

/** "افتح اعدادات X" shortcuts. */
object SettingsMap {
    private val map: List<Pair<List<String>, String>> = listOf(
        listOf("واي فاي", "wifi", "الشبكه") to Settings.ACTION_WIFI_SETTINGS,
        listOf("بلوتوث", "bluetooth") to Settings.ACTION_BLUETOOTH_SETTINGS,
        listOf("الشاشه", "العرض", "السطوع", "display") to Settings.ACTION_DISPLAY_SETTINGS,
        listOf("الصوت", "الرنين", "sound") to Settings.ACTION_SOUND_SETTINGS,
        listOf("البطاريه", "battery") to Settings.ACTION_BATTERY_SAVER_SETTINGS,
        listOf("التطبيقات", "apps") to Settings.ACTION_APPLICATION_SETTINGS,
        listOf("الموقع", "gps", "location") to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        listOf("الوصول", "accessibility") to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        listOf("حول الهاتف", "معلومات الهاتف") to Settings.ACTION_DEVICE_INFO_SETTINGS,
        listOf("التاريخ", "الوقت") to Settings.ACTION_DATE_SETTINGS,
        listOf("اللغه", "اللغات", "language") to Settings.ACTION_LOCALE_SETTINGS,
        listOf("التخزين", "storage") to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        listOf("nfc") to Settings.ACTION_NFC_SETTINGS,
        listOf("الطيران", "airplane") to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        listOf("الامان", "الحمايه", "security") to Settings.ACTION_SECURITY_SETTINGS,
        listOf("الخصوصيه", "privacy") to Settings.ACTION_PRIVACY_SETTINGS,
        listOf("لوحه المفاتيح", "keyboard") to Settings.ACTION_INPUT_METHOD_SETTINGS,
        listOf("الاتصالات", "شبكه الجوال", "wireless") to Settings.ACTION_WIRELESS_SETTINGS,
        listOf("المطور", "developer") to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS
    )

    fun open(ctx: Context, spoken: String): Boolean {
        val t = Normalizer.norm(spoken)
        val action = map.firstOrNull { (keys, _) -> keys.any { t.contains(Normalizer.norm(it)) } }?.second
            ?: return false
        return Actions.launch(ctx, Intent(action))
    }
}
