package com.example.voicecontrol

import java.net.URI
import java.security.MessageDigest

/** Heuristic phishing check for links + password check against known breaches (k-anonymity, password never sent). */
object LinkChecker {

    private val badTlds = setOf("zip", "mov", "tk", "ml", "ga", "cf", "gq", "xyz", "top", "click", "work", "country", "kim", "loan")
    private val words = listOf("login", "verify", "secure", "account", "update", "wallet", "bank", "gift", "claim", "confirm", "signin")
    private val brands = listOf(
        "google", "paypal", "apple", "microsoft", "facebook", "instagram", "whatsapp", "netflix",
        "amazon", "binance", "twitter", "telegram", "snapchat", "tiktok"
    )

    fun analyze(input: String): Pair<Int, List<String>> {
        val reasons = ArrayList<String>()
        var risk = 0
        var raw = input.trim()
        if (!raw.contains("://")) raw = "http://$raw"
        val host = try { URI(raw).host?.lowercase() } catch (e: Exception) { null }
        if (host == null) return 60 to listOf("الرابط غير صالح الشكل")

        if (raw.startsWith("http://")) { risk += 15; reasons.add("بدون تشفير HTTPS (أو لم يُكتب البروتوكول)") }
        if (Regex("^\\d{1,3}(\\.\\d{1,3}){3}$").matches(host)) { risk += 30; reasons.add("العنوان رقم IP بدل اسم موقع") }
        if (host.contains("xn--")) { risk += 30; reasons.add("اسم يحتوي أحرفاً مموّهة تشبه حروفاً أخرى") }
        if (raw.substringAfter("://").substringBefore('/').contains('@')) { risk += 30; reasons.add("علامة @ تخفي الوجهة الحقيقية") }
        if (host.count { it == '.' } >= 4) { risk += 15; reasons.add("نطاقات فرعية كثيرة") }
        if (host.substringAfterLast('.') in badTlds) { risk += 15; reasons.add("امتداد نطاق يكثر استخدامه في الاحتيال") }
        if (raw.length > 75) { risk += 10; reasons.add("رابط طويل جداً") }
        val w = words.count { host.contains(it) }
        if (w > 0) { risk += (w * 10).coerceAtMost(20); reasons.add("كلمات تستخدم في الخداع داخل الاسم") }

        val norm = host.replace('0', 'o').replace('1', 'l').replace('3', 'e').replace('5', 's')
        for (b in brands) {
            if (norm.contains(b)) {
                val official = host == "$b.com" || host.endsWith(".$b.com") || host == "$b.net" || host.endsWith(".$b.net") ||
                    (b == "twitter" && (host == "x.com" || host.endsWith(".x.com")))
                if (!official) { risk += 30; reasons.add("يشبه اسم $b لكنه ليس موقعه الرسمي"); break }
            }
        }
        return risk.coerceAtMost(100) to reasons
    }

    fun report(input: String): String {
        val (risk, reasons) = analyze(input)
        val verdict = when { risk >= 50 -> "خطر مرتفع، لا تفتحه"; risk >= 20 -> "مشبوه، احذر"; else -> "لا مؤشرات واضحة" }
        val sb = StringBuilder("> فحص الرابط\nالنتيجة: $verdict ($risk/100)\n")
        for (r in reasons) sb.append("[!] ").append(r).append('\n')
        sb.append("\nهذا فحص تقديري، وغياب المؤشرات لا يضمن أن الموقع آمن.")
        return sb.toString()
    }

    fun passwordStrength(p: String): String {
        var classes = 0
        if (p.any { it.isLowerCase() }) classes++
        if (p.any { it.isUpperCase() }) classes++
        if (p.any { it.isDigit() }) classes++
        if (p.any { !it.isLetterOrDigit() }) classes++
        val common = listOf("123456", "password", "qwerty", "admin", "iloveyou", "111111", "000000")
        return when {
            common.any { p.lowercase().contains(it) } -> "ضعيفة جداً: تحتوي نمطاً شائعاً"
            p.length < 8 -> "ضعيفة: أقل من 8 أحرف"
            p.length >= 14 && classes >= 3 -> "قوية"
            p.length >= 10 && classes >= 3 -> "جيدة"
            else -> "متوسطة: زد الطول وتنوّع الأحرف"
        }
    }

    /** Call off the main thread. Only the first 5 characters of the SHA-1 hash are sent. */
    fun pwned(password: String): Int {
        val sha = MessageDigest.getInstance("SHA-1").digest(password.toByteArray())
            .joinToString("") { "%02X".format(it) }
        val prefix = sha.take(5)
        val suffix = sha.drop(5)
        val c = java.net.URL("https://api.pwnedpasswords.com/range/$prefix").openConnection() as java.net.HttpURLConnection
        c.connectTimeout = 10000
        c.readTimeout = 10000
        val body = c.inputStream.bufferedReader().use { it.readText() }
        for (line in body.lines()) {
            val parts = line.trim().split(':')
            if (parts.size == 2 && parts[0].equals(suffix, true)) return parts[1].trim().toIntOrNull() ?: 1
        }
        return 0
    }
}
