package com.example.voicecontrol

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Two animated eyes that look around, blink and show moods. Draws on a transparent background. */
class EyesView(ctx: Context) : View(ctx) {

    var mood: Mood = Mood.IDLE

    private var gx = 0f
    private var gy = 0f
    private var tx = 0f
    private var ty = 0f
    private var lid = 0f
    private var tilt = 0f
    private var scale = 1f
    private var blinkAmt = 0f
    private var blinkStart = -1L
    private var nextBlink = 0L
    private var nextGaze = 0L
    private var last = 0L

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val oval = Path()
    private val lidPath = Path()
    private val rect = RectF()

    private val tick = object : Runnable {
        override fun run() {
            step()
            invalidate()
            if (isAttachedToWindow) postOnAnimation(this)
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postOnAnimation(tick)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(tick)
        super.onDetachedFromWindow()
    }

    private fun color(): Int = when (mood) {
        Mood.IDLE, Mood.SPEAKING, Mood.CURIOUS -> 0xFF00E5FF.toInt()
        Mood.LISTENING, Mood.HAPPY -> 0xFF00FF9C.toInt()
        Mood.THINKING -> 0xFFFFC107.toInt()
        Mood.SAD -> 0xFF5C8DFF.toInt()
        Mood.ANGRY, Mood.ALERT -> 0xFFFF3D3D.toInt()
        Mood.SLEEPY -> 0xFF4A6572.toInt()
        Mood.SURPRISED -> 0xFFB388FF.toInt()
    }

    private fun step() {
        val now = SystemClock.uptimeMillis()
        val dt = if (last == 0L) 16f else (now - last).coerceAtMost(50L).toFloat()
        last = now

        var targetLid = 0f
        var targetTilt = 0f
        var targetScale = 1f
        when (mood) {
            Mood.LISTENING -> targetScale = 1.12f
            Mood.THINKING -> targetLid = 0.18f
            Mood.SPEAKING -> targetScale = 1f + 0.05f * sin(now / 120.0).toFloat()
            Mood.SAD -> { targetLid = 0.3f; targetTilt = -1f }
            Mood.ANGRY -> { targetLid = 0.35f; targetTilt = 1f }
            Mood.ALERT -> { targetScale = 1.2f; targetLid = 0.15f; targetTilt = 0.6f }
            Mood.SLEEPY -> targetLid = 0.85f
            Mood.SURPRISED -> targetScale = 1.3f
            else -> {}
        }
        val k = 1f - exp(-dt / 90f)
        lid += (targetLid - lid) * k
        tilt += (targetTilt - tilt) * k
        scale += (targetScale - scale) * k

        if (now >= nextGaze) {
            when (mood) {
                Mood.THINKING -> { tx = if (tx <= 0f) 0.8f else -0.8f; ty = -0.7f; nextGaze = now + 700L }
                Mood.LISTENING -> { tx = 0f; ty = -0.1f; nextGaze = now + 1500L }
                Mood.SLEEPY -> { tx = 0f; ty = 0.5f; nextGaze = now + 3000L }
                Mood.CURIOUS -> {
                    tx = Random.nextFloat() * 2f - 1f
                    ty = Random.nextFloat() * 1.2f - 0.6f
                    nextGaze = now + 400L
                }
                else -> {
                    tx = Random.nextFloat() * 2f - 1f
                    ty = Random.nextFloat() * 1.4f - 0.7f
                    nextGaze = now + 1200L + Random.nextLong(2500L)
                }
            }
        }
        val g = 1f - exp(-dt / 70f)
        gx += (tx - gx) * g
        gy += (ty - gy) * g

        if (blinkStart < 0L && now >= nextBlink && mood != Mood.SLEEPY && mood != Mood.HAPPY) {
            blinkStart = now
        }
        blinkAmt = 0f
        if (blinkStart >= 0L) {
            val p = (now - blinkStart) / 160f
            if (p >= 1f) {
                blinkStart = -1L
                nextBlink = now + 2500L + Random.nextLong(3500L)
            } else {
                blinkAmt = 1f - abs(2f * p - 1f)
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val baseW = min(w * 0.38f, h * 0.95f)
        val baseH = min(h * 0.9f, baseW * 1.1f)
        val ew = baseW * scale
        val eh = baseH * scale
        val cy = h / 2f
        val col = color()
        drawEye(canvas, w / 2f - ew * 0.62f, cy, ew, eh, true, col)
        drawEye(canvas, w / 2f + ew * 0.62f, cy, ew, eh, false, col)
    }

    private fun drawEye(c: Canvas, cx: Float, cy: Float, ew: Float, eh: Float, left: Boolean, col: Int) {
        val rx = ew / 2f
        val ry = eh / 2f

        if (mood == Mood.HAPPY) {
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = ry * 0.35f
            paint.strokeCap = Paint.Cap.ROUND
            paint.color = col
            rect.set(cx - rx * 0.8f, cy - ry * 0.5f, cx + rx * 0.8f, cy + ry * 0.9f)
            c.drawArc(rect, 200f, 140f, false, paint)
            paint.style = Paint.Style.FILL
            return
        }

        val cover = (lid + blinkAmt * (1f - lid)).coerceIn(0f, 1f)
        oval.reset()
        rect.set(cx - rx, cy - ry, cx + rx, cy + ry)
        oval.addOval(rect, Path.Direction.CW)

        val top = cy - ry
        val outerY = top + eh * (cover - tilt * 0.25f)
        val innerY = top + eh * (cover + tilt * 0.25f)
        val yl = if (left) outerY else innerY
        val yr = if (left) innerY else outerY
        lidPath.reset()
        lidPath.moveTo(cx - rx - 4f, top - eh)
        lidPath.lineTo(cx + rx + 4f, top - eh)
        lidPath.lineTo(cx + rx + 4f, yr)
        lidPath.lineTo(cx - rx - 4f, yl)
        lidPath.close()
        path.reset()
        path.op(oval, lidPath, Path.Op.DIFFERENCE)

        paint.style = Paint.Style.STROKE
        paint.strokeWidth = ry * 0.18f
        paint.color = (col and 0x00FFFFFF) or 0x55000000
        c.drawPath(path, paint)

        paint.style = Paint.Style.FILL
        paint.color = 0xFFF4FBFF.toInt()
        c.drawPath(path, paint)

        c.save()
        c.clipPath(path)
        val r = min(rx, ry)
        val px = cx + gx * rx * 0.38f
        val py = cy + gy * ry * 0.38f
        paint.color = col
        c.drawCircle(px, py, r * 0.66f, paint)
        paint.color = 0xFF04121A.toInt()
        c.drawCircle(px, py, r * 0.34f, paint)
        paint.color = Color.WHITE
        c.drawCircle(px - r * 0.14f, py - r * 0.16f, r * 0.11f, paint)
        c.restore()
    }
}
