package com.example.voicecontrol

import android.app.KeyguardManager
import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** level: 2 = high risk, 1 = medium, 0 = fine / info */
data class Finding(val level: Int, val title: String, val detail: String)

/** Defensive checks only: tells the owner how exposed the phone is. Nothing leaves the device. */
object SecurityScanner {

    fun score(f: List<Finding>): Int =
        (100 - f.sumOf { when (it.level) { 2 -> 15; 1 -> 6; else -> 0 } }).coerceIn(0, 100)

    fun deviceScan(ctx: Context): List<Finding> {
        val out = ArrayList<Finding>()
        val cr = ctx.contentResolver

        val km = ctx.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (km.isDeviceSecure) out.add(Finding(0, "قفل الشاشة", "مفعّل"))
        else out.add(Finding(2, "لا يوجد قفل للشاشة", "فعّل رمز PIN أو بصمة أو كلمة مرور قوية"))

        if (Settings.Global.getInt(cr, Settings.Global.ADB_ENABLED, 0) == 1)
            out.add(Finding(2, "تصحيح USB مفعّل", "عطّله إلا إذا كنت تحتاجه، فهو يسمح بالتحكم بالهاتف عبر الكابل"))
        if (Settings.Global.getInt(cr, Settings.Global.DEVELOPMENT_SETTINGS_ENABLED, 0) == 1)
            out.add(Finding(1, "خيارات المطور مفعّلة", "عطّلها إن لم تكن تستخدمها"))

        try {
            val d = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(Build.VERSION.SECURITY_PATCH)
            if (d != null) {
                val days = (Date().time - d.time) / 86400000L
                if (days > 180) out.add(Finding(2, "تحديث الأمان قديم", "آخر تحديث أمني قبل $days يوماً. حدّث النظام"))
                else if (days > 90) out.add(Finding(1, "تحديث الأمان يقترب من القدم", "قبل $days يوماً"))
                else out.add(Finding(0, "تحديث الأمان", "حديث"))
            }
        } catch (e: Exception) { }

        if (Build.VERSION.SDK_INT < 30)
            out.add(Finding(1, "نسخة أندرويد قديمة", "أندرويد ${Build.VERSION.RELEASE} لا يتلقى معظم الحماية الحديثة"))

        val rootPaths = listOf("/system/bin/su", "/system/xbin/su", "/sbin/su", "/system/app/Superuser.apk")
        if (rootPaths.any { File(it).exists() } || (Build.TAGS ?: "").contains("test-keys"))
            out.add(Finding(2, "مؤشرات روت أو نظام معدّل", "الهاتف قد يكون مفتوح الصلاحيات، وهذا يضعف الحماية"))

        val enabledA11y = (Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .split(':').filter { it.isNotBlank() }
        for (s in enabledA11y) {
            if (s.startsWith(ctx.packageName) || s.contains("talkback", true) || s.contains("accessibility.", true) && s.startsWith("com.google.android")) continue
            out.add(Finding(1, "خدمة وصول أخرى مفعّلة", "$s — هذه الخدمات تستطيع قراءة الشاشة، تأكد أنك تعرفها"))
        }

        val listeners = (Settings.Secure.getString(cr, "enabled_notification_listeners") ?: "")
            .split(':').filter { it.isNotBlank() }
        if (listeners.size > 3) out.add(Finding(1, "تطبيقات كثيرة تقرأ الإشعارات", "عددها ${listeners.size}، راجعها من الإعدادات"))

        try {
            val dpm = ctx.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admins = dpm.activeAdmins
            if (admins != null && admins.isNotEmpty())
                out.add(Finding(1, "تطبيقات مسؤول الجهاز", admins.joinToString { it.packageName }))
        } catch (e: Exception) { }

        try {
            val cm = ctx.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN))
                out.add(Finding(0, "VPN", "مفعّل"))
        } catch (e: Exception) { }

        if (Build.VERSION.SDK_INT >= 31) {
            try {
                @Suppress("DEPRECATION")
                val info = (ctx.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager).connectionInfo
                if (info != null && info.networkId != -1) {
                    when (info.currentSecurityType) {
                        0 -> out.add(Finding(2, "شبكة واي فاي مفتوحة", "أي شخص قريب يستطيع التنصت. تجنب البنوك وكلمات المرور أو استخدم VPN"))
                        1 -> out.add(Finding(2, "شبكة واي فاي بتشفير WEP", "تشفير قديم يُكسر بسهولة"))
                        else -> {}
                    }
                }
            } catch (e: Exception) { }
        }
        return out
    }

    private val trustedStores = setOf(
        "com.android.vending", "com.sec.android.app.samsungapps", "com.huawei.appmarket",
        "com.xiaomi.mipicks", "com.amazon.venezia", "com.heytap.market", "com.vivo.appstore"
    )

    private val weights = mapOf(
        "android.permission.READ_SMS" to 3, "android.permission.RECEIVE_SMS" to 2,
        "android.permission.SEND_SMS" to 3, "android.permission.READ_CALL_LOG" to 2,
        "android.permission.SYSTEM_ALERT_WINDOW" to 2, "android.permission.REQUEST_INSTALL_PACKAGES" to 2,
        "android.permission.MANAGE_EXTERNAL_STORAGE" to 2, "android.permission.RECORD_AUDIO" to 1,
        "android.permission.READ_CONTACTS" to 1, "android.permission.BIND_DEVICE_ADMIN" to 3
    )

    private val arabicPerm = mapOf(
        "READ_SMS" to "قراءة الرسائل", "RECEIVE_SMS" to "استقبال الرسائل", "SEND_SMS" to "إرسال رسائل",
        "READ_CALL_LOG" to "سجل المكالمات", "SYSTEM_ALERT_WINDOW" to "الظهور فوق التطبيقات",
        "REQUEST_INSTALL_PACKAGES" to "تثبيت تطبيقات", "MANAGE_EXTERNAL_STORAGE" to "كل الملفات",
        "RECORD_AUDIO" to "الميكروفون", "READ_CONTACTS" to "جهات الاتصال", "BIND_DEVICE_ADMIN" to "مسؤول الجهاز"
    )

    @Suppress("DEPRECATION")
    fun appScan(ctx: Context): List<Finding> {
        val pm = ctx.packageManager
        val scored = ArrayList<Pair<Int, Finding>>()
        val pkgs = try { pm.getInstalledPackages(PackageManager.GET_PERMISSIONS) } catch (e: Exception) { emptyList() }
        for (p in pkgs) {
            val ai = p.applicationInfo ?: continue
            if (ai.flags and ApplicationInfo.FLAG_SYSTEM != 0 || p.packageName == ctx.packageName) continue
            val perms = p.requestedPermissions?.toSet() ?: emptySet()
            val hit = perms.filter { weights.containsKey(it) }
            val points = hit.sumOf { weights[it] ?: 0 }
            val installer = try {
                if (Build.VERSION.SDK_INT >= 30) pm.getInstallSourceInfo(p.packageName).installingPackageName
                else pm.getInstallerPackageName(p.packageName)
            } catch (e: Exception) { null }
            val sideloaded = installer == null || installer !in trustedStores
            val label = try { pm.getApplicationLabel(ai).toString() } catch (e: Exception) { p.packageName }
            val names = hit.joinToString("، ") { arabicPerm[it.substringAfterLast('.')] ?: it.substringAfterLast('.') }
            when {
                sideloaded && points >= 4 ->
                    scored.add(points + 5 to Finding(2, "تطبيق مشبوه: $label", "من خارج المتجر ويطلب: $names"))
                points >= 7 ->
                    scored.add(points to Finding(1, "صلاحيات واسعة: $label", names))
            }
        }
        return scored.sortedByDescending { it.first }.take(8).map { it.second }
    }

    fun report(title: String, f: List<Finding>): String {
        val sb = StringBuilder("> $title\n")
        val bad = f.filter { it.level > 0 }
        for (x in bad) sb.append(if (x.level == 2) "[!] " else "[~] ").append(x.title).append(" — ").append(x.detail).append('\n')
        val ok = f.filter { it.level == 0 }
        if (ok.isNotEmpty()) sb.append("[+] سليم: ").append(ok.joinToString("، ") { it.title }).append('\n')
        if (bad.isEmpty()) sb.append("لم أجد مشاكل ظاهرة.\n")
        sb.append("\nملاحظة: هذه مؤشرات وليست دليلاً قاطعاً على وجود برمجية خبيثة.")
        return sb.toString()
    }

    fun speech(name: String, f: List<Finding>): String {
        val s = score(f)
        val bad = f.filter { it.level > 0 }.sortedByDescending { it.level }.take(3)
        return if (bad.isEmpty()) "أستاذ $name، درجة الأمان $s من 100 ولم أجد مشاكل ظاهرة"
        else "أستاذ $name، درجة الأمان $s من 100. أهم الملاحظات: " + bad.joinToString("، ") { it.title }
    }
}
