package com.example.voicecontrol

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Picture
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Hexagon grid + moving scan line over the whole screen (cyber look). */
class CyberBackdropView(ctx: Context) : View(ctx) {
    private val picture = Picture()
    private val band = Paint()
    private var bandH = 0f
    private var y = 0f
    private var last = 0L

    private val tick = object : Runnable {
        override fun run() {
            val now = SystemClock.uptimeMillis()
            val dt = if (last == 0L) 16L else (now - last).coerceAtMost(50L)
            last = now
            y += dt * 0.12f
            if (y > height + bandH) y = -bandH
            invalidate()
            if (isAttachedToWindow) postOnAnimation(this)
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); postOnAnimation(tick) }
    override fun onDetachedFromWindow() { removeCallbacks(tick); super.onDetachedFromWindow() }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        if (w == 0 || h == 0) return
        val r = w / 11f
        val path = Path()
        var row = 0
        var cy = 0f
        while (cy < h + r) {
            var cx = if (row % 2 == 0) 0f else r * 1.5f
            while (cx < w + r) {
                for (i in 0..5) {
                    val a = Math.toRadians(60.0 * i)
                    val px = cx + r * 0.95f * cos(a).toFloat()
                    val py = cy + r * 0.95f * sin(a).toFloat()
                    if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
                }
                path.close()
                cx += r * 3f
            }
            cy += r * 0.866f
            row++
        }
        val c = picture.beginRecording(w, h)
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 1.2f
        p.color = 0x2200E5FF
        c.drawPath(path, p)
        picture.endRecording()
        bandH = h * 0.12f
        band.shader = LinearGradient(
            0f, 0f, 0f, bandH,
            intArrayOf(0x0000E5FF, 0x3300E5FF, 0x0000E5FF), null, Shader.TileMode.CLAMP
        )
    }

    override fun onDraw(canvas: Canvas) {
        if (width == 0) return
        canvas.drawPicture(picture)
        canvas.save()
        canvas.translate(0f, y - bandH)
        canvas.drawRect(0f, 0f, width.toFloat(), bandH, band)
        canvas.restore()
    }
}

/** Shield with a check mark. */
class ShieldView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    var color: Int = 0xFF00E5FF.toInt()
        set(v) { field = v; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        path.reset()
        path.moveTo(w * 0.5f, h * 0.04f)
        path.lineTo(w * 0.9f, h * 0.2f)
        path.lineTo(w * 0.9f, h * 0.52f)
        path.quadTo(w * 0.9f, h * 0.8f, w * 0.5f, h * 0.97f)
        path.quadTo(w * 0.1f, h * 0.8f, w * 0.1f, h * 0.52f)
        path.lineTo(w * 0.1f, h * 0.2f)
        path.close()
        p.style = Paint.Style.FILL
        p.color = (color and 0x00FFFFFF) or 0x33000000
        c.drawPath(path, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.06f
        p.strokeJoin = Paint.Join.ROUND
        p.color = color
        c.drawPath(path, p)
        p.strokeCap = Paint.Cap.ROUND
        c.drawLine(w * 0.3f, h * 0.5f, w * 0.45f, h * 0.65f, p)
        c.drawLine(w * 0.45f, h * 0.65f, w * 0.72f, h * 0.35f, p)
    }
}

/** Circular score gauge with a radar sweep while scanning. */
class ScoreView(ctx: Context) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rect = RectF()
    private var score = -1
    private var scanning = false
    private var t0 = 0L

    private val tick = object : Runnable {
        override fun run() {
            invalidate()
            if (scanning && isAttachedToWindow) postOnAnimation(this)
        }
    }

    fun startScan() { scanning = true; t0 = SystemClock.uptimeMillis(); postOnAnimation(tick) }
    fun setScore(s: Int) { score = s; scanning = false; invalidate() }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val r = min(w, h) * 0.42f
        val cx = w / 2f
        val cy = h / 2f
        rect.set(cx - r, cy - r, cx + r, cy + r)

        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.16f
        p.strokeCap = Paint.Cap.ROUND
        p.color = 0x3300E5FF
        c.drawArc(rect, 0f, 360f, false, p)

        if (scanning) {
            val a = ((SystemClock.uptimeMillis() - t0) % 1600L) / 1600f * 360f
            p.color = 0xFF00FF9C.toInt()
            c.drawArc(rect, a, 70f, false, p)
            p.strokeWidth = 2f
            p.color = 0x5500FF9C
            c.drawCircle(cx, cy, r * 0.6f, p)
            c.drawCircle(cx, cy, r * 0.3f, p)
            val rad = Math.toRadians(a.toDouble() + 70.0)
            c.drawLine(cx, cy, cx + r * cos(rad).toFloat(), cy + r * sin(rad).toFloat(), p)
        } else if (score >= 0) {
            p.color = when { score >= 80 -> 0xFF00FF9C.toInt(); score >= 55 -> 0xFFFFC107.toInt(); else -> 0xFFFF3D3D.toInt() }
            c.drawArc(rect, -90f, 360f * score / 100f, false, p)
        }

        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.color = Color.WHITE
        p.textSize = r * 0.6f
        p.typeface = android.graphics.Typeface.MONOSPACE
        val label = if (scanning) "···" else if (score >= 0) score.toString() else "--"
        c.drawText(label, cx, cy + r * 0.2f, p)
    }
}
