package com.example.voicecontrol

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val cyan = 0xFF00E5FF.toInt()
    private val green = 0xFF00FF9C.toInt()
    private val red = 0xFFFF5252.toInt()
    private val grey = 0xFF8FA3AD.toInt()

    private lateinit var tListen: TextView
    private lateinit var tAccess: TextView
    private lateinit var tEyes: TextView
    private lateinit var toggle: Button
    private lateinit var terminal: TextView
    private lateinit var score: ScoreView
    private lateinit var nameField: EditText
    private lateinit var wake: EditText
    private lateinit var needWake: Switch
    private lateinit var english: Switch
    private lateinit var useClaude: Switch
    private lateinit var key: EditText

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun box(fill: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(fill)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun lp(top: Int = 10) = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(top) }

    private fun card(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(14), dp(12), dp(14), dp(12))
        background = box(0xCC08121C.toInt(), 0x6600E5FF, 16)
    }

    private fun tv(s: String, size: Float, color: Int, bold: Boolean = false, mono: Boolean = false): TextView =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            if (mono) typeface = Typeface.MONOSPACE
        }

    private fun smallBtn(s: String, onClick: () -> Unit): Button = Button(this).apply {
        text = s
        isAllCaps = false
        setTextColor(Color.WHITE)
        textSize = 13f
        background = box(0x3300E5FF, 0x8800E5FF.toInt(), 10)
        setOnClickListener { onClick() }
    }

    private fun tile(emoji: String, label: String, onClick: () -> Unit): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(6), dp(10), dp(6), dp(10))
        background = box(0xCC08121C.toInt(), 0x8800E5FF.toInt(), 14)
        addView(tv(emoji, 26f, Color.WHITE))
        addView(tv(label, 12f, Color.WHITE).apply { gravity = Gravity.CENTER })
        setOnClickListener { onClick() }
    }

    private fun gridRow(a: View, b: View): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        val m = dp(4)
        addView(a, LinearLayout.LayoutParams(0, dp(88), 1f).apply { setMargins(m, m, m, m) })
        addView(b, LinearLayout.LayoutParams(0, dp(88), 1f).apply { setMargins(m, m, m, m) })
    }

    private fun field(e: EditText): EditText = e.apply {
        setTextColor(Color.WHITE)
        setHintTextColor(0x99FFFFFF.toInt())
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = 0xFF05080F.toInt()
        window.navigationBarColor = 0xFF05080F.toInt()
        val match = ViewGroup.LayoutParams.MATCH_PARENT

        val frame = FrameLayout(this)
        frame.addView(
            ImageView(this).apply {
                setImageResource(R.drawable.bg_painting)
                scaleType = ImageView.ScaleType.CENTER_CROP
            },
            FrameLayout.LayoutParams(match, match)
        )
        frame.addView(View(this).apply { setBackgroundColor(0x99050A12.toInt()) }, FrameLayout.LayoutParams(match, match))
        frame.addView(CyberBackdropView(this), FrameLayout.LayoutParams(match, match))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(16), dp(14), dp(28))
        }
        frame.addView(ScrollView(this).apply { addView(col) }, FrameLayout.LayoutParams(match, match))

        // ---- header with live eyes ----
        val head = card()
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(ShieldView(this), LinearLayout.LayoutParams(dp(44), dp(44)))
        val titles = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), 0, dp(10), 0) }
        titles.addView(tv("المساعد الذكي", 20f, Color.WHITE, bold = true))
        titles.addView(tv("SECURE VOICE CORE", 11f, cyan, mono = true))
        row.addView(titles)
        head.addView(row)
        head.addView(EyesView(this), LinearLayout.LayoutParams(match, dp(100)))
        col.addView(head, lp(0))

        // ---- status ----
        val st = card()
        val stRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        tListen = tv("", 12f, grey, mono = true)
        tAccess = tv("", 12f, grey, mono = true)
        tEyes = tv("", 12f, grey, mono = true)
        for (t in listOf(tListen, tAccess, tEyes)) stRow.addView(t, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        st.addView(stRow)
        col.addView(st, lp())

        // ---- main toggle ----
        toggle = Button(this).apply {
            textSize = 17f
            isAllCaps = false
            setTextColor(Color.BLACK)
            setOnClickListener { toggleListening() }
        }
        col.addView(toggle, LinearLayout.LayoutParams(match, dp(60)).apply { topMargin = dp(10) })

        // ---- tiles ----
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        grid.addView(gridRow(
            tile("🛡", "فحص أمان الهاتف") { runDeviceScan() },
            tile("📦", "فحص التطبيقات") { runAppScan() }
        ))
        grid.addView(gridRow(
            tile("👁", "تشغيل/إيقاف العيون") { toggleEyes() },
            tile("😴", "وضع النوم") { sleepMode() }
        ))
        grid.addView(gridRow(
            tile("🌐", "ترجمة نص للعربية") { translateDialog() },
            tile("🔗", "فحص رابط") { linkDialog() }
        ))
        grid.addView(gridRow(
            tile("🔑", "فحص كلمة مرور") { passwordDialog() },
            tile("📖", "الأوامر") { terminal.text = HELP }
        ))
        col.addView(grid, lp(6))

        // ---- score + terminal ----
        val sec = card()
        score = ScoreView(this)
        sec.addView(score, LinearLayout.LayoutParams(match, dp(140)))
        terminal = tv("> جاهز. اختر فحصاً من الأزرار أعلاه أو قل: يا هاتف افحص أمان الهاتف", 12f, green, mono = true).apply {
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = box(0xE6020A0F.toInt(), 0x6600FF9C, 10)
            setTextIsSelectable(true)
        }
        sec.addView(terminal, lp(8))
        col.addView(sec, lp())

        // ---- setup ----
        val setup = card()
        setup.addView(tv("الإعداد الأولي", 14f, cyan, bold = true))
        setup.addView(smallBtn("1) منح الصلاحيات") { askPermissions() }, lp(6))
        setup.addView(smallBtn("2) تفعيل خدمة إمكانية الوصول") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }, lp(6))
        setup.addView(smallBtn("3) السماح بالظهور فوق التطبيقات") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        }, lp(6))
        setup.addView(smallBtn("4) تعطيل تحسين البطارية") {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
        }, lp(6))
        col.addView(setup, lp())

        // ---- settings ----
        val set = card()
        set.addView(tv("الإعدادات", 14f, cyan, bold = true))
        nameField = field(EditText(this)).apply { hint = "اسمك (ينادونك به)"; setText(Prefs.userName(this@MainActivity)) }
        wake = field(EditText(this)).apply { hint = "كلمة التنبيه"; setText(Prefs.wakeWord(this@MainActivity)) }
        needWake = Switch(this).apply { text = "اشترط كلمة التنبيه"; setTextColor(Color.WHITE); isChecked = Prefs.requireWake(this@MainActivity) }
        english = Switch(this).apply { text = "English"; setTextColor(Color.WHITE); isChecked = Prefs.lang(this@MainActivity).startsWith("en") }
        useClaude = Switch(this).apply { text = "استخدم Claude بدل Gemini"; setTextColor(Color.WHITE); isChecked = Prefs.provider(this@MainActivity) == "claude" }
        key = field(EditText(this)).apply {
            hint = "مفتاح Gemini المجاني (aistudio.google.com)"
            setText(Prefs.apiKey(this@MainActivity))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        for (v in listOf(nameField, wake, needWake, english, useClaude, key)) set.addView(v, lp(4))
        set.addView(smallBtn("حفظ الإعدادات") { savePrefs(); toast("تم الحفظ") }, lp(8))
        col.addView(set, lp())

        setContentView(frame)
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val on = VoiceService.running
        tListen.text = "● الاستماع\n" + if (on) "يعمل" else "متوقف"
        tListen.setTextColor(if (on) green else grey)
        val acc = PhoneControlService.instance != null
        tAccess.text = "● الوصول\n" + if (acc) "مفعّل" else "غير مفعّل"
        tAccess.setTextColor(if (acc) green else red)
        val eyes = Prefs.eyesOn(this)
        tEyes.text = "● العيون\n" + if (eyes) "ظاهرة" else "مخفية"
        tEyes.setTextColor(if (eyes) green else grey)
        toggle.text = if (on) "■  إيقاف الاستماع" else "▶  تشغيل الاستماع"
        toggle.background = box(if (on) red else green, Color.TRANSPARENT, 16)
    }

    private fun savePrefs() {
        Prefs.save(
            this, key.text.toString(), wake.text.toString(), needWake.isChecked,
            if (english.isChecked) "en-US" else "ar-SA", nameField.text.toString(),
            if (useClaude.isChecked) "claude" else "gemini"
        )
    }

    private fun toggleListening() {
        if (VoiceService.running) {
            VoiceService.stop(this)
        } else {
            savePrefs()
            VoiceService.start(this)
        }
        toggle.postDelayed({ refresh() }, 400L)
        refresh()
    }

    private fun toggleEyes() {
        val svc = PhoneControlService.instance
        if (svc == null) { toast("فعّل خدمة إمكانية الوصول أولاً"); return }
        val on = !Prefs.eyesOn(this)
        Prefs.setEyes(this, on)
        if (on) svc.eyes?.show() else svc.eyes?.hide()
        refresh()
    }

    private fun sleepMode() {
        val svc = PhoneControlService.instance
        if (svc == null) { toast("فعّل خدمة إمكانية الوصول أولاً"); return }
        svc.eyes?.enterSleep()
    }

    private fun runDeviceScan() {
        score.startScan()
        terminal.text = "> جارٍ فحص الجهاز..."
        Thread {
            val f = SecurityScanner.deviceScan(this)
            val rep = SecurityScanner.report("فحص أمان الجهاز", f)
            runOnUiThread { score.setScore(SecurityScanner.score(f)); terminal.text = rep }
        }.start()
    }

    private fun runAppScan() {
        score.startScan()
        terminal.text = "> جارٍ فحص التطبيقات..."
        Thread {
            val f = SecurityScanner.appScan(this)
            val rep = SecurityScanner.report("فحص التطبيقات المثبتة", f)
            runOnUiThread { score.setScore(SecurityScanner.score(f)); terminal.text = rep }
        }.start()
    }

    private fun ask(title: String, hint: String, password: Boolean = false, onOk: (String) -> Unit) {
        val et = EditText(this).apply {
            this.hint = hint
            if (password) inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(et)
            .setPositiveButton("تنفيذ") { _, _ -> onOk(et.text.toString()) }
            .setNegativeButton("إلغاء", null)
            .show()
    }

    private fun linkDialog() = ask("فحص رابط", "الصق الرابط هنا") { terminal.text = LinkChecker.report(it) }

    private fun passwordDialog() = ask("فحص كلمة مرور", "اكتب كلمة المرور", true) { pw ->
        terminal.text = "> جارٍ الفحص..."
        Thread {
            val strength = LinkChecker.passwordStrength(pw)
            val leaks = try {
                val n = LinkChecker.pwned(pw)
                if (n > 0) "ظهرت في تسريبات بيانات $n مرة، لا تستخدمها" else "لم تظهر في التسريبات المعروفة"
            } catch (e: Exception) { "تعذر فحص التسريبات (تحقق من الإنترنت)" }
            runOnUiThread {
                terminal.text = "> فحص كلمة المرور\nالقوة: $strength\nالتسريبات: $leaks\n\n" +
                    "كلمتك لا تُرسل لأي جهة، يُرسل جزء صغير من بصمتها فقط."
            }
        }.start()
    }

    private fun translateDialog() = ask("ترجمة إلى العربية", "اكتب أو الصق النص بأي لغة") { txt ->
        if (Prefs.apiKey(this).isBlank()) { terminal.text = "> أضف مفتاح Gemini المجاني في الإعدادات أولاً"; return@ask }
        terminal.text = "> جارٍ الترجمة..."
        AgentClient.translateText(this, txt) { terminal.text = it }
    }

    private fun askPermissions() {
        val p = mutableListOf(
            Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        requestPermissions(p.toTypedArray(), 1)
    }

    companion object {
        private const val HELP = "> أمثلة (ابدأ بـ: يا هاتف)\n" +
            "• افتح يوتيوب / ارجع / الرئيسية / انزل / اطلع\n" +
            "• ابدأ الكتابة ... انتهيت / اكتب مرحبا / ارسل\n" +
            "• تصفح / افتح موقع google.com / ابحث عن ...\n" +
            "• ترجم الشاشة (بأي لغة إلى العربية)\n" +
            "• افحص أمان الهاتف / افحص التطبيقات\n" +
            "• اظهر العيون / اخف العيون / وضع النوم / استيقظ\n" +
            "• افرح / اغضب / احزن / تفاجأ\n" +
            "• اطفي الشاشة / اتصل بـ ... / مؤقت 10 دقائق\n" +
            "• افتح اعدادات الواي فاي / كم الساعة / كم البطارية\n" +
            "• وأي سؤال أو أمر آخر بكلامك العادي (يحتاج المفتاح)"
    }
}
