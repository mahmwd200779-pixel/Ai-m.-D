package com.example.voicecontrol

import android.content.Context
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent

/** Turns a spoken sentence into an action. Fast local rules first, the AI (Claude) for everything else. */
object CommandRouter {

    @Volatile var dictating = false

    private fun rx(p: String) = Regex(p, RegexOption.IGNORE_CASE)

    fun handle(ctx: Context, raw: String, speakRaw: (String) -> Unit) {
        val name = Prefs.userName(ctx)
        val ack = "حاضر أستاذ $name"
        val speak: (String) -> Unit = { m -> speakRaw(if (m == "تم") ack else m) }
        val t = Normalizer.norm(raw)
        val svc = PhoneControlService.instance

        fun need(block: (PhoneControlService) -> Unit) {
            if (svc == null) speak("فعّل خدمة إمكانية الوصول أولاً") else block(svc)
        }
        fun ok(b: Boolean, done: String = "تم", fail: String = "لم أستطع") = speak(if (b) done else fail)
        fun any(vararg k: String) = k.any { t == Normalizer.norm(it) }
        fun starts(vararg k: String) = k.any { t.startsWith(Normalizer.norm(it)) }
        fun has(vararg k: String) = k.any { t.contains(Normalizer.norm(it)) }
        val wantAppScan = has("فحص") && has("التطبيقات", "تطبيقات")
        val wantDeviceScan = has("فحص") && has("امان", "الهاتف", "الجهاز") && !wantAppScan

        // ---------- dictation mode: everything you say is typed ----------
        if (dictating) {
            when {
                any("انتهيت", "خلصت", "توقف عن الكتابه", "وقف الكتابه", "stop typing", "done") -> {
                    dictating = false; speak("تمام أستاذ $name، أنهيت الكتابة")
                }
                any("ارسل", "ارسال", "send") -> need { ok(it.pressEnter()) }
                any("امسح", "امسح الكل", "clear") -> need { ok(it.clearText()) }
                else -> need { if (!it.appendText(raw)) speak("لا يوجد حقل نص مفتوح") }
            }
            return
        }

        when {
            // ---- control of the listener itself ----
            any("توقف عن الاستماع", "وقف الاستماع", "stop listening") -> {
                speak("حسناً أستاذ $name، أوقفت الاستماع"); VoiceService.stop(ctx)
            }

            // ---- dictation ----
            any("ابدا الكتابه", "وضع الكتابه", "املي", "اكتب بالصوت", "start typing", "dictate") -> {
                dictating = true
                speak("حاضر أستاذ $name، تفضل أنا أكتب ما تقوله. قل انتهيت عند الانتهاء")
            }

            // ---- navigation ----
            any("ارجع", "رجوع", "للخلف", "back", "go back") -> need { ok(it.back()) }
            any("الرئيسيه", "الشاشه الرئيسيه", "روح للرئيسيه", "home", "go home") -> need { ok(it.home()) }
            any("التطبيقات الاخيره", "التطبيقات المفتوحه", "recent apps", "recents") -> need { ok(it.recents()) }
            any("الاشعارات", "افتح الاشعارات", "notifications") -> need { ok(it.notifications()) }
            any("الاعدادات السريعه", "quick settings") -> need { ok(it.quickSettings()) }
            any("لقطه شاشه", "صور الشاشه", "خذ لقطه", "screenshot") -> need { ok(it.screenshot()) }
            has("اطفي الشاشه", "اطفئ الشاشه", "سكر الشاشه", "اقفل الشاشه", "قفل الشاشه", "lock screen", "screen off", "turn off the screen") ->
                need { ok(it.lockScreen()) }
            any("قائمه الطاقه", "اطفاء الهاتف", "power menu") -> need { ok(it.powerMenu()) }
            any("شغل الشاشه", "صحي الشاشه", "نور الشاشه", "wake screen") -> { Actions.wakeScreen(ctx); speak("تم") }

            // ---- scrolling / swiping ----
            starts("انزل", "نزل", "مرر لتحت", "مرر للاسفل", "scroll down", "لتحت", "تحت") -> need { it.scroll(true); speak("تم") }
            starts("اطلع", "ارفع الشاشه", "مرر لفوق", "مرر للاعلي", "مرر للاعلى", "scroll up", "لفوق", "فوق") -> need { it.scroll(false); speak("تم") }
            starts("اسحب يمين", "swipe right") -> need { it.swipeSide(false); speak("تم") }
            starts("اسحب يسار", "swipe left") -> need { it.swipeSide(true); speak("تم") }

            // ---- keyboard ----
            any("ارسل", "ارسال", "انتر", "enter", "send", "بحث", "search") -> need { ok(it.pressEnter()) }

            // ---- reading ----
            any("اقرا الشاشه", "اقراء الشاشه", "اقرا الصفحه", "read screen", "read the page") -> need {
                val s = it.readableText(); speak(if (s.isBlank()) "لا يوجد نص ظاهر" else s)
            }

            // ---- information that needs no internet ----
            any("كم الساعه", "الساعه كم", "الوقت", "what time is it", "time") ->
                speak(java.text.SimpleDateFormat("h:mm a", java.util.Locale("ar")).format(java.util.Date()))
            any("ما التاريخ", "اي يوم اليوم", "التاريخ", "what is the date", "date") ->
                speak(java.text.SimpleDateFormat("EEEE d MMMM yyyy", java.util.Locale("ar")).format(java.util.Date()))
            any("كم البطاريه", "نسبه البطاريه", "البطاريه", "battery") -> {
                val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as android.os.BatteryManager
                speak("البطارية ${bm.getIntProperty(android.os.BatteryManager.BATTERY_PROPERTY_CAPACITY)} بالمئة")
            }
            has("واي فاي", "wifi", "wi-fi", "وايفاي") && has("شغل", "اطفي", "افتح", "فعل", "turn", "open") ->
                ok(Actions.launch(ctx, android.content.Intent(android.provider.Settings.ACTION_WIFI_SETTINGS)))
            has("بلوتوث", "bluetooth") && has("شغل", "اطفي", "افتح", "فعل", "turn", "open") ->
                ok(Actions.launch(ctx, android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)))

            // ---- cybersecurity (defensive) ----
            wantAppScan -> scanAsync(ctx, true, speak)
            wantDeviceScan || any("security scan", "scan my phone") -> scanAsync(ctx, false, speak)

            // ---- eyes ----
            has("اظهر العيون", "شغل العيون", "افتح العيون", "show eyes") -> { Prefs.setEyes(ctx, true); svc?.eyes?.show(); speak("تم") }
            has("اخف العيون", "اطفي العيون", "سكر العيون", "hide eyes") -> { Prefs.setEyes(ctx, false); svc?.eyes?.hide(); speak("تم") }
            any("نام", "وضع النوم", "روح نام", "sleep mode", "sleep") -> need { speak("تصبح على خير أستاذ $name"); it.eyes?.enterSleep() }
            any("استيقظ", "اصحي", "صباح الخير", "wake up") -> need { it.eyes?.exitSleep(); speak("صباح النور أستاذ $name") }
            any("افرح", "كن سعيد", "كن سعيدا") -> { speak("تم"); Eyes.mood(Mood.HAPPY, 3500L) }
            any("اغضب", "كن غاضب", "كن غاضبا") -> { speak("تم"); Eyes.mood(Mood.ANGRY, 3500L) }
            any("احزن", "كن حزين", "كن حزينا") -> { speak("تم"); Eyes.mood(Mood.SAD, 3500L) }
            any("تفاجا", "اندهش") -> { speak("تم"); Eyes.mood(Mood.SURPRISED, 3500L) }

            // ---- translation ----
            has("ترجم الشاشه", "ترجم الصفحه", "ترجم لي الشاشه", "translate screen") ->
                if (Prefs.apiKey(ctx).isBlank()) speak("للترجمة أضف مفتاح Gemini المجاني في التطبيق")
                else AgentClient.translateScreen(ctx, speak)

            // ---- browser ----
            any("تصفح", "افتح المتصفح", "المتصفح", "browser") -> ok(Actions.openBrowser(ctx))

            // ---- media control (video / music) ----
            any("قدم", "قدم الفيديو", "تقدم", "forward", "fast forward") -> { Actions.seek(ctx, 10); speak("تم") }
            any("ارجع الفيديو", "رجع الفيديو", "ارجع 10 ثواني", "rewind", "back 10") -> { Actions.seek(ctx, -10); speak("تم") }
            any("اوقف الفيديو", "ايقاف الفيديو", "وقف الفيديو", "اضغط الفيديو") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE); speak("تم") }
            any("شغل الصوت", "الصوت شغل", "unmute", "unmute sound") -> { Actions.volume(ctx, AudioManager.ADJUST_UNMUTE); speak("تم") }
            any("كتم", "اكتم الصوت", "اكتم", "صامت", "silence") -> { Actions.volume(ctx, AudioManager.ADJUST_MUTE); speak("تم") }
            any("اعلى صوت", "اقصى صوت", "max volume") -> { Actions.setVolumePercent(ctx, 100); speak("تم") }
            any("صوت متوسط", "نص الصوت") -> { Actions.setVolumePercent(ctx, 50); speak("تم") }
            any("اخفض السطوع", "قلل السطوع", "dim screen") -> { Actions.brightness(ctx, 0.1f); speak("تم") }
            any("ارفع السطوع", "زد السطوع", "bright screen") -> { Actions.brightness(ctx, 1f); speak("تم") }
            any("الشاشه تدور", "افتح التدوير", "auto rotate on") -> { Actions.autoRotate(ctx, true); speak("تم") }
            any("وقف التدوير", "اقفل التدوير", "auto rotate off") -> { Actions.autoRotate(ctx, false); speak("تم") }
            any("لا تزعجني", "وضع عدم الازعاج", "do not disturb", "dnd") -> { Actions.dnd(ctx, true); speak("تم") }
            any("اطفي عدم الازعاج", "الغ عدم الازعاج") -> { Actions.dnd(ctx, false); speak("تم") }
            any("الوقت كم", "كم الساعه الان") -> speak(java.text.SimpleDateFormat("h:mm a", java.util.Locale("ar")).format(java.util.Date()))
            any("وضع الطيران", "الطيران") -> ok(Actions.launch(ctx, android.content.Intent(android.provider.Settings.ACTION_AIRPLANE_MODE_SETTINGS)))
            any("شغل البلوتوث", "اطفي البلوتوث") -> ok(Actions.launch(ctx, android.content.Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS)))
            any("الكاميرا الاماميه", "كاميرا السيلفي", "selfie") -> Actions.camera(ctx, true).also { speak("تم") }
            any("صوّر", "التقط صوره", "take photo", "take picture") -> { Actions.camera(ctx, false); speak("تم") }
            any("سجل فيديو", "ابدأ التسجيل", "record video") -> { Actions.recordVideo(ctx); speak("تم") }
            any("افتح الملفات", "مدير الملفات", "files", "my files") -> { Actions.openFiles(ctx); speak("تم") }
            any("افتح المعرض", "الصور", "gallery", "photos") -> { Actions.openGallery(ctx); speak("تم") }
            any("افتح الخريطه", "خرائط", "maps", "open maps") -> { Actions.openMaps(ctx); speak("تم") }
            any("رسائل", "افتح الرسائل", "messages") -> { Actions.openSms(ctx); speak("تم") }
            any("اقفل التطبيق", "اغلق التطبيق", "close app", "force stop") -> need { ok(it.back()) }
            any("اغلق الكل", "امسح التطبيقات", "close all") -> need { it.recents(); speak("تم") }
            any("اضف مؤقت", "مؤقت") -> { speak("كم دقيقة أستاذ $name؟") }
            any("اخترني", "عشوائي", "اختار لي رقم", "random number") -> speak((1..100).random().toString())
            any("عملة", "اقلب عملة", "flip coin") -> speak(if (kotlin.random.Random.nextBoolean()) "وجه" else "ظهر")
            any("نكتة", "قل لي نكته", "tell joke") -> speak("ليش الكمبيوتر ما يحب يتعب؟ لأنه دايماً يخاف من الفيروسات يا أستاذ $name")
            any("اهدي", "اخبرني عن نفسك", "من انت", "who are you") ->
                speak("أنا مساعدك الذكي يا أستاذ $name، أتحكم بهاتفك بصوتك وأحمي خصوصيتك وأترجم لك")
            // ---- hardware ----
            rx("^(?:شغل|افتح|اضيء|اضئ|turn on)\\s+(?:الكشاف|الفلاش|المصباح|flashlight|torch)").containsMatchIn(t) ->
                ok(Actions.torch(ctx, true))
            rx("^(?:اطفي|اطفئ|سكر|اغلق|turn off)\\s+(?:الكشاف|الفلاش|المصباح|flashlight|torch)").containsMatchIn(t) ->
                ok(Actions.torch(ctx, false))
            starts("ارفع الصوت", "زود الصوت", "volume up", "louder") -> { Actions.volume(ctx, AudioManager.ADJUST_RAISE); speak("تم") }
            starts("اخفض الصوت", "وطي الصوت", "نقص الصوت", "volume down", "quieter") -> { Actions.volume(ctx, AudioManager.ADJUST_LOWER); speak("تم") }
            starts("كتم الصوت", "mute") -> { Actions.volume(ctx, AudioManager.ADJUST_MUTE); speak("تم") }
            any("وقف الموسيقى", "ايقاف مؤقت", "pause", "pause music") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PAUSE); speak("تم") }
            any("شغل الموسيقى", "كمل الموسيقى", "play", "play music", "resume") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PLAY); speak("تم") }
            any("التالي", "الاغنيه التاليه", "next", "next song") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_NEXT); speak("تم") }
            any("السابق", "الاغنيه السابقه", "previous", "previous song") -> { Actions.mediaKey(ctx, KeyEvent.KEYCODE_MEDIA_PREVIOUS); speak("تم") }

            else -> handleWithArgs(ctx, raw, t, svc, speak)
        }
    }

    private fun handleWithArgs(
        ctx: Context, raw: String, t: String, svc: PhoneControlService?, speak: (String) -> Unit
    ) {
        fun ok(b: Boolean, done: String = "تم", fail: String = "لم أستطع") = speak(if (b) done else fail)

        rx("^(?:اضغط|اختار)\\s+(\\d+)$").find(t)?.let { m ->
            if (svc == null) return speak("فعّل خدمة إمكانية الوصول أولاً")
            return ok(svc.clickText(m.groupValues[1]), "تم", "لم أجد الزر")
        }
        rx("^(?:قدم|تقدم)\\s+(\\d+)\\s*(?:ثانيه|ثواني|ثوانٍ|sec)").find(t)?.let { m ->
            return ok(Actions.seek(ctx, m.groupValues[1].toInt()).let { true }, "تم")
        }
        rx("^(?:ارجع|رجع)\\s+(\\d+)\\s*(?:ثانيه|ثواني|ثوانٍ|sec)").find(t)?.let { m ->
            return ok(Actions.seek(ctx, -m.groupValues[1].toInt()).let { true }, "تم")
        }
        rx("^(?:اطلب|اكتب|افتح)\\s+(?:رقم\\s+)?(\\d+)\\s*(?:دقيقه|دقايق|دقائق)?$").find(t)?.let { m ->
            return ok(Actions.setTimer(ctx, m.groupValues[1].toInt()), "ضبطت المؤقت")
        }
        // type text (raw text keeps the original spelling)
        rx("^\\s*(?:اكتب|type|write)\\s+(.+)").find(raw)?.let { m ->
            if (svc == null) return speak("فعّل خدمة إمكانية الوصول أولاً")
            return ok(svc.appendText(m.groupValues[1].trim()), "تم", "لا يوجد حقل نص مفتوح")
        }
        if (rx("^(?:امسح النص|امسح الكتابه|clear text)$").containsMatchIn(t)) {
            return ok(svc?.clearText() == true)
        }
        rx("^(?:اضغط(?: علي| على)?|انقر(?: علي| على)?|اختار|click(?: on)?|tap(?: on)?|press)\\s+(.+)").find(t)?.let { m ->
            if (svc == null) return speak("فعّل خدمة إمكانية الوصول أولاً")
            return ok(svc.clickText(m.groupValues[1]), "تم", "لم أجد ${m.groupValues[1]}")
        }
        rx("^(?:افتح موقع|افتح الموقع|روح الي موقع|روح الي|اذهب الي|تصفح|go to|browse|open website)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.openUrl(ctx, m.groupValues[1]))
        }
        rx("^(?:ابحث عن|دور على|دور علي|search for|search|google)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.webSearch(ctx, m.groupValues[1]))
        }
        rx("^(?:اتصل ب|اتصل بـ|كلم|call|phone)\\s+(.+)").find(t)?.let { m ->
            return ok(Actions.call(ctx, m.groupValues[1]), "أتصل الآن", "لم أجد الرقم")
        }
        rx("(\\d+)\\s*(?:دقيقه|دقايق|دقائق|دقيقة|minutes?|mins?)").find(t)?.let { m ->
            if (t.contains("مؤقت") || t.contains("timer") || t.contains("منبه"))
                return ok(Actions.setTimer(ctx, m.groupValues[1].toInt()), "ضبطت المؤقت")
        }
        rx("^(?:افتح\\s+)?اعدادات\\s+(.+)").find(t)?.let { m ->
            if (SettingsMap.open(ctx, m.groupValues[1])) return speak("تم")
        }
        rx("^(?:افتح|شغل تطبيق|شغل|open|launch|start)\\s+(.+)").find(t)?.let { m ->
            if (Actions.openApp(ctx, m.groupValues[1])) return speak("تم")
            // not an installed app name → fall through to the AI
        }

        // everything else: talk with Claude (questions, chat, complex phone tasks)
        if (Prefs.apiKey(ctx).isNotBlank()) {
            AgentClient.run(ctx, raw, speak)
        } else {
            speak("لم أفهم: $raw. أضف مفتاح Gemini المجاني في التطبيق لأتحدث معك وأفهم أي أمر")
        }
    }

    private fun scanAsync(ctx: Context, apps: Boolean, speak: (String) -> Unit) {
        val name = Prefs.userName(ctx)
        Eyes.mood(Mood.THINKING, 15000L)
        Thread {
            val f = if (apps) SecurityScanner.appScan(ctx) else SecurityScanner.deviceScan(ctx)
            val msg = if (apps) {
                if (f.isEmpty()) "أستاذ $name، لم أجد تطبيقات مشبوهة"
                else "أستاذ $name، وجدت ${f.size} تطبيقات تستحق المراجعة، أولها " + f.first().title.substringAfter(": ")
            } else SecurityScanner.speech(name, f)
            val alert = f.any { it.level == 2 }
            Handler(Looper.getMainLooper()).post {
                speak(msg)
                if (alert) Eyes.mood(Mood.ALERT, 5000L)
            }
        }.start()
    }
}
