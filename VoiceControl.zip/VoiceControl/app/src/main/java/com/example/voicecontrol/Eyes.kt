package com.example.voicecontrol

enum class Mood { IDLE, LISTENING, THINKING, SPEAKING, HAPPY, SAD, ANGRY, ALERT, SLEEPY, SURPRISED, CURIOUS }

/** Tiny helper so any class can change the eyes' mood. ms = 0 means "stay", otherwise revert afterwards. */
object Eyes {
    fun mood(m: Mood, ms: Long = 0) {
        PhoneControlService.instance?.eyes?.setMood(m, ms)
    }
}
